git init
git add .
git commit -m "Initial site"
git remote add origin https://github.com/YOUR_USERNAME/lapetitefleur.git
git branch -M main
git push -u origin main