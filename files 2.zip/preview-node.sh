# install once: npm i -g serve
serve .
# then open the URL printed by the command