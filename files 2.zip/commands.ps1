# create project folder and open (PowerShell)
New-Item -ItemType Directory -Path . -Name lapetitefleur
Set-Location lapetitefleur

# create images folder
New-Item -ItemType Directory -Path . -Name images

# open in VS Code
code .