// Small interactivity: mobile nav toggle + contact form UX
document.addEventListener('DOMContentLoaded', () => {
  const nav = document.getElementById('nav');
  const toggle = document.getElementById('nav-toggle');
  const year = document.getElementById('year');
  const form = document.getElementById('contact-form');
  const msg = document.getElementById('form-msg');
  const submitButton = document.getElementById('submit-button');

  year.textContent = new Date().getFullYear();

  // Mobile nav toggle
  toggle.addEventListener('click', () => {
    const showing = nav.classList.toggle('show');
    toggle.setAttribute('aria-expanded', String(showing));
  });

  // Close mobile nav when a link is clicked (better UX)
  nav.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      if (nav.classList.contains('show')) {
        nav.classList.remove('show');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  });

  // Form handling
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    msg.textContent = '';
    msg.style.color = ''; // reset

    const formData = new FormData(form);
    const action = (form.getAttribute('action') || '').trim();

    // Basic validation
    const name = (formData.get('name') || '').toString().trim();
    const email = (formData.get('email') || '').toString().trim();
    const message = (formData.get('message') || '').toString().trim();

    if (!name || !email || !message) {
      msg.textContent = 'Please fill out name, email, and message.';
      msg.style.color = '#c67a6a';
      return;
    }

    // If no real endpoint set, simulate success and remind user
    if (!action || action.includes('yourformid')) {
      msg.textContent = 'Demo: message prepared. Replace the form "action" with your Formspree URL or another endpoint to enable messages.';
      msg.style.color = '#6A907B';
      form.reset();
      return;
    }

    // Disable submit while sending
    submitButton.disabled = true;
    submitButton.setAttribute('aria-busy', 'true');

    try {
      const resp = await fetch(action, {
        method: 'POST',
        headers: { Accept: 'application/json' },
        body: formData
      });

      if (resp.ok) {
        msg.textContent = 'Thank you — your request has been sent.';
        msg.style.color = '#6A907B';
        form.reset();
      } else {
        // attempt to read JSON error if provided
        let data = {};
        try { data = await resp.json(); } catch (_) { /* ignore */ }
        msg.textContent = data.error || 'Sorry — there was a problem sending your message.';
        msg.style.color = '#c67a6a';
      }
    } catch (err) {
      msg.textContent = 'Network error. Please try again later.';
      msg.style.color = '#c67a6a';
    } finally {
      submitButton.disabled = false;
      submitButton.removeAttribute('aria-busy');
    }
  });
});