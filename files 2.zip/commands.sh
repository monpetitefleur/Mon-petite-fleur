# create project folder and open (macOS/Linux)
mkdir lapetitefleur
cd lapetitefleur

# create images folder
mkdir images

# open folder in VS Code (if installed)
code .