# Python 3
python3 -m http.server 8000
# then open http://localhost:8000 in your browser