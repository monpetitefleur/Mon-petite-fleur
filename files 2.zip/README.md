# La Petite Fleur — Small French Cottage Website

This is a small, single-page static site scaffold designed to feel like a French cottage:
dusty pinks, sage green, rustic paper textures, and copy that emphasizes handmade, meaningful floristry.

Included files
- `index.html` — main single-page site (Home / Our Story / Services / Gallery / Contact)
- `styles.css` — styles, colors, fonts
- `script.js` — minimal interactivity (mobile nav + contact form UX)
- `images/` — place your photos here: `hero.jpg`, `bouquet1.jpg`, `bouquet2.jpg`, `bouquet3.jpg`, `bouquet4.jpg`

What you need to finish
1. Images
   - Replace the placeholder images in `/images` with your own high-res photos (recommended: soft, warm light).
   - The hero background file should be `images/hero.jpg`.

2. Contact form
   - Current form action points to a Formspree placeholder:
     `https://formspree.io/f/yourformid`
   - Replace `yourformid` with your actual Formspree form ID, or set another endpoint (server or service) to receive POSTs.
   - If you leave the placeholder, the site will show a demo success message instead of sending.

3. Deploy
   - Host as static files on GitHub Pages, Netlify, Vercel, or any static host.
   - For GitHub Pages: push to a repository and enable Pages from the default branch (or `gh-pages` branch).

Optional enhancements
- Add a small SVG floral motif or logo in the header.
- Provide real testimonials in the quote area or add more gallery items.
- Integrate a lightbox for gallery images.
- Add a simple booking flow or Stripe integration for paid orders.

If you’d like, I can:
- Add your photos (upload them here) and I will place/rescale them into `images/`.
- Replace the Formspree placeholder with your real form ID and test submission.
- Push these files to a GitHub repo (tell me owner/repo and confirm).
- Convert to a small multi-page site or a Next.js app.

Tell me which of the above you'd like me to do next.